import { MetadataRoute } from 'next';
import { cities } from '@/data/cities';

export default async function sitemap({ id }: { id: Promise<string> | string }): Promise<MetadataRoute.Sitemap> {
    const baseUrl = 'https://межгород.com';
    const resolvedId = await id;

    const fromCity = cities.find(c => c.id === resolvedId);
    if (!fromCity) return [];

    const routes: MetadataRoute.Sitemap = [];

    // Generate dynamic routes only for this specific departure city
    cities.forEach(toCity => {
        if (fromCity.id !== toCity.id) {
            routes.push({
                url: `${baseUrl}/routes/${fromCity.id}/${toCity.id}`,
                lastModified: new Date(),
                changeFrequency: 'monthly',
                priority: 0.6,
            });
        }
    });

    return routes;
}
